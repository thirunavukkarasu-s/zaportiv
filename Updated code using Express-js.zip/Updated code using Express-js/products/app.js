const express = require('express');
const compression = require('compression');
const bodyParser = require('body-parser');
const { checkLogin, getByPagination, create, validateProductInput, verifyToken, checkIsAdmin,
   getProductById, getProductsByCategoryId, getAllProducts } = require('./controllers'); 

const app = express();
const port = 3000;

app.use(compression()); //to compress the response
app.use(bodyParser.json());

app.post('/login', checkLogin);
app.get('/products/page/:number', verifyToken, getByPagination); 
app.get('/products/:id', verifyToken, getProductById); 
app.get('/products/category/:categoryId', verifyToken, getProductsByCategoryId); 
app.post('/products', verifyToken, checkIsAdmin, validateProductInput, create);
app.get('/products', verifyToken, getAllProducts); 

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});