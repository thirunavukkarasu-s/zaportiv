const jwt = require('jsonwebtoken');
const { secretKey } = require('./config');

const { 
    findAllProducts,
    findProductById,
    findProductsByCategoryId,
    checkLogin: checkLoginModel,
    findByPagination,
    createProduct
 } = require('./models');


const checkLogin = async (req, res, next) => {
    const { username, password } = req.body;
    const result = await checkLoginModel(username, password);
    if (result.error) {
      res.status(401).json(result.error);
      return;
    }
    res.status(200).json({ token: result.token });
    next()
  };
  

  const getByPagination = async (req, res, next) => {
    try {
      const pageNumber = req.params.number;
      const products = await findByPagination(pageNumber);
      if (products.error) {
        throw new Error(products.error);
      }
      res.status(200).json(products);
    } catch (err) {
      console.error('Error querying database:', err);
      res.status(500).json('Error querying database');
    }
    next()
  };

const create = async (req, res, next) => {
    const productData = req.body;
    const result = await createProduct(productData);
    if (result.success) {
      res.status(201).json(result);
    } else {
      res.status(500).json(result);
    }
    next();
};

const getAllProducts = async (req, res, next) => {
    try {
      const products = await findAllProducts();
      res.status(200).json(products);
    } catch (err) {
      console.error('Error retrieving products:', err);
      res.status(500).json('Error retrieving products');
    }
  };
  
  const getProductById = async (req, res, next) => {
    const productId = req.params.id;
    try {
      const product = await findProductById(productId);
      res.status(200).json(product);
    } catch (err) {
      console.error('Error retrieving product by id:', err);
      res.status(500).json('Error retrieving product by id');
    }
  };

  const getProductsByCategoryId = async (req, res, next) => {
    const categoryId = req.params.categoryId;
    try {
      const products = await findProductsByCategoryId(categoryId);
      res.status(200).json(products);
    } catch (err) {
      console.error('Error retrieving products by category id:', err);
      res.status(500).json('Error retrieving products by category id');
    }
  };

  const validateProductInput = (req, res, next) => {
    const { name, code, description, categoryId, price, availability } = req.body;
    if (!name || !code || !price || !availability) {
      res.status(400).json({ error: 'Missing required fields' });
      return;
    }
    if (isNaN(parseFloat(price))) {
      res.status(400).json({ error: 'Price must be a number' });
      return;
    }
    if (isNaN(categoryId) || !Number.isInteger(categoryId)) {
      res.status(400).json({ error: 'Category Id must be a valid integer' });
      return;
    }
    next();
  };

  const verifyToken = async (req, res, next) => {
    const authorizationHeader = req.headers.authorization;
  
    if (!authorizationHeader) {
      res.status(401).json({ error: 'Unauthorized: Missing token' });
      return;
    }
    const token = authorizationHeader.split(' ')[1];
  
    try {
      console.log(secretKey, token)
      const decodedToken = jwt.verify(token, secretKey);
      req.user = decodedToken;
      await next(); // Proceed to the next middleware
    } catch (err) {
      res.status(401).json({ error: 'Unauthorized: Invalid token' });
    }
  };
  
  const checkIsAdmin = async (req, res, next) => {
    if (req.user.role === 'admin') {
      await next(); // User is an admin, proceed to the next middleware
    } else {
      res.status(403).json({ error: 'You are unauthorized for this action' });
    }
  };

module.exports = {
  checkLogin,
  getByPagination,
  create,
  validateProductInput,
  verifyToken,
  checkIsAdmin,
  getProductById,
  getProductsByCategoryId,
  getAllProducts
};