const sql = require('mssql');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { poolPromise, secretKey, sqlQueries } = require('./config');

const findAllProducts = async () => {
  try {
    const pool = await poolPromise;
    const result = await pool.request().query(sqlQueries.selectAllProducts);
    return result.recordset;
  } catch (err) {
    console.error('Error retrieving all products:', err);
    throw new Error('Error retrieving all products');
  }
};

const findProductById = async (productId) => {
  try {
    const pool = await poolPromise;
    const request = pool.request();
    request.input('productId', productId);
    const result = await request.query(sqlQueries.selectProductById);
    return result.recordset;
  } catch (err) {
    console.error('Error retrieving product by ID:', err);
    throw new Error('Error retrieving product by ID');
  }
};

const findProductsByCategoryId = async (categoryId) => {
  try {
    const pool = await poolPromise;
    const request = pool.request();
    request.input('categoryId', categoryId);
    const result = await request.query(sqlQueries.selectProductsByCategoryId);
    return result.recordset;
  } catch (err) {
    console.error('Error retrieving products by category ID:', err);
    throw new Error('Error retrieving products by category ID');
  }
};

const checkLogin = async (username, password) => {
    try {
      const pool = await poolPromise;
      const request = pool.request();
      request.input('Username', username);
      const result = await request.query(sqlQueries.selectUser);

      if (!result.recordset || result.recordset.length === 0) {
        return { error: 'Invalid username or password' };
      }
  
      const user = result.recordset[0];
      const passwordMatch = await bcrypt.compare(password, user.Password);
      if (!passwordMatch) {
        return { error: 'Invalid username or password' };
      }
  
      console.log(secretKey)
      const token = jwt.sign({ userId: user.Id, role: user.Role }, secretKey, { expiresIn: '1h' });
      return { token };
    } catch (err) {
      console.error('Error during login:', err);
      return { error: 'Error during login' };
    }
  };
  
  const findByPagination = async (pageNumber) => {
    try {
      const pageSize = 10;
      const startIndex = (pageNumber - 1) * pageSize + 1;
      const endIndex = pageNumber * pageSize;
  
      const pool = await poolPromise;
      const request = pool.request();
      request.input('StartIndex', startIndex);
      request.input('EndIndex', endIndex);
      const result = await request.query(sqlQueries.selectByPagination);

      return result.recordset;
    } catch (err) {
      console.error('Error querying database:', err);
      return { error: 'Error querying database' };
    }
  };
  
  const createProduct = async (productData) => {
    const { name, code, description, categoryId, price, availability } = productData;
  
    try {
      const pool = await poolPromise;
      
      const request = pool.request();
      request.input('Name', sql.NVarChar, name);
      request.input('Code', sql.NVarChar, code);
      request.input('Description', sql.NVarChar, description || null);
      request.input('CategoryId', sql.Int, categoryId || null);
      request.input('Price', sql.Decimal(18, 2), price);
      request.input('Availability', sql.Int, availability);

      const result = await request.query(sqlQueries.createProduct);
      return { success: true, productId: result.recordset[0].InsertedProductId };
    } catch (err) {
      console.error('Error adding product:', err);
      return { success: false, message: 'Error adding product' };
    }
  };

module.exports = { findAllProducts, findProductById, findProductsByCategoryId, checkLogin, findByPagination, createProduct };