const sql = require('mssql');
const crypto = require('crypto');

const config = {
  user: 'sa',
  password: 'smtools',
  server: 'LAPTOP-6QPR18MT', 
  database: 'ProductCatalogDB',
  options: {
    encrypt: false, 
    enableArithAbort: true, 
  },
};

const secretKey = crypto.randomBytes(32).toString('hex');

const poolPromise = new sql.ConnectionPool(config)
  .connect()
  .then((pool) => {
    console.log('Connected to SQL Server database');
    return pool;
  })
  .catch((err) => {
    console.error('Error connecting to SQL Server:', err);
    process.exit(1);
  });

  const sqlQueries = {
    selectAllProducts: `SELECT * FROM products`,

    selectProductById: `SELECT p.*, c.name as CategoryName 
                     FROM products p 
                     JOIN categories c ON p.categoryid = c.id 
                     WHERE p.id = @productId`,

    selectProductsByCategoryId: `SELECT p.*, c.name as CategoryName 
                               FROM products p 
                               JOIN categories c ON p.categoryid = c.id 
                               WHERE c.id = @categoryId`,

    selectUser: `SELECT u.*, r.Code Role 
                 FROM Users u 
                 JOIN Roles r ON u.RoleId = r.Id 
                 WHERE u.name = @Username`,

    selectByPagination: `
                SELECT * FROM (
                  SELECT ROW_NUMBER() OVER (ORDER BY id DESC) AS RowNum, * 
                  FROM products
                ) AS t
                WHERE RowNum BETWEEN @StartIndex AND @EndIndex`,

    createProduct: `INSERT INTO Products (Name, Code, Description, CategoryId, Price, Availability)
                    VALUES (@Name, @Code, @Description, @CategoryId, @Price, @Availability);
                    SELECT SCOPE_IDENTITY() AS InsertedProductId;`,
  };

module.exports = { config, secretKey, poolPromise, sqlQueries };