const sql = require('mssql');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const { poolPromise, secretKey } = require('./config');

const findAllProducts = async () => {
  const pool = await poolPromise;
  const result = await pool.request().query(`SELECT * FROM products`);
  return result.recordset;
};

const findProductById = async (productId) => {
  const pool = await poolPromise;
  const result = await pool.request().query(`
    SELECT p.*, c.name as CategoryName 
    FROM products p 
    JOIN categories c ON p.categoryid = c.id 
    WHERE p.id = ${productId}
  `);
  return result.recordset;
};

const findProductsByCategoryId = async (categoryId) => {
  const pool = await poolPromise;
  const result = await pool.request().query(`
    SELECT p.*, c.name as CategoryName 
    FROM products p 
    JOIN categories c ON p.categoryid = c.id 
    WHERE c.id = ${categoryId}
  `);
  return result.recordset;
};

const checkLogin = async (username, password) => {
    try {
      const pool = await poolPromise;
      const result = await pool
        .request()
        .input('Username', sql.NVarChar, username)
        .query('SELECT u.*, r.Code Role FROM Users u join Roles r on u.RoleId = r.Id WHERE u.name = @Username');
  
      if (!result.recordset || result.recordset.length === 0) {
        return { error: 'Invalid username or password' };
      }
  
      const user = result.recordset[0];
      const passwordMatch = await bcrypt.compare(password, user.Password);
      if (!passwordMatch) {
        return { error: 'Invalid username or password' };
      }
  
      console.log(secretKey)
      const token = jwt.sign({ userId: user.Id, role: user.Role }, secretKey, { expiresIn: '1h' });
      return { token };
    } catch (err) {
      console.error('Error during login:', err);
      return { error: 'Error during login' };
    }
  };
  
  const findByPagination = async (pageNumber) => {
    try {
      const pageSize = 10;
      const pool = await poolPromise;
      const result = await pool
        .request()
        .query(`
          SELECT * FROM (
            SELECT ROW_NUMBER() OVER (ORDER BY id DESC) AS RowNum, * 
            FROM products
          ) AS t
          WHERE RowNum BETWEEN ${(pageNumber - 1) * pageSize + 1} AND ${pageNumber * pageSize}
        `);
      return result.recordset;
    } catch (err) {
      console.error('Error querying database:', err);
      return { error: 'Error querying database' };
    }
  };
  
  const createProduct = async (productData) => {
    const { name, code, description, categoryId, price, availability } = productData;
  
    try {
      const pool = await poolPromise;
      const result = await pool
        .request()
        .input('Name', sql.NVarChar, name)
        .input('Code', sql.NVarChar, code)
        .input('Description', sql.NVarChar, description || null)
        .input('CategoryId', sql.Int, categoryId || null)
        .input('Price', sql.Decimal(18, 2), price)
        .input('Availability', sql.Int, availability)
        .query(`
          INSERT INTO Products (Name, Code, Description, CategoryId, Price, Availability)
          VALUES (@Name, @Code, @Description, @CategoryId, @Price, @Availability);
    
          SELECT SCOPE_IDENTITY() AS InsertedProductId;
        `);
      return { success: true, productId: result.recordset[0].InsertedProductId };
    } catch (err) {
      console.error('Error adding product:', err);
      return { success: false, message: 'Error adding product' };
    }
  };

module.exports = { findAllProducts, findProductById, findProductsByCategoryId, checkLogin, findByPagination, createProduct };