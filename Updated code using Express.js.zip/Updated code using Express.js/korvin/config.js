const sql = require('mssql');
const crypto = require('crypto');

const config = {
  user: 'sa',
  password: 'smtools',
  server: 'LAPTOP-6QPR18MT', 
  database: 'korvin',
  options: {
    encrypt: false, 
    enableArithAbort: true, 
  },
};

const secretKey = crypto.randomBytes(32).toString('hex');
const poolPromise = new sql.ConnectionPool(config)
  .connect()
  .then((pool) => {
    console.log('Connected to SQL Server database');
    return pool;
  })
  .catch((err) => {
    console.error('Error connecting to SQL Server:', err);
    process.exit(1);
  });

module.exports = { config, secretKey, poolPromise };