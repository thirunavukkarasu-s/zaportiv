const express = require('express');
const bodyParser = require('body-parser');
const { checkLogin, getByPagination, create, validateProductInput, verifyToken, checkIsAdmin, getProductById, getProductsByCategoryId, getAllProducts } = require('./controllers'); // Ensure correct method names are imported

const app = express();
const port = 3000;

app.use(bodyParser.json());

app.post('/login', checkLogin);
app.get('/products/page/:number', verifyToken, getByPagination); // Changed to getByPagination
app.get('/products/:id', verifyToken, getProductById); // Added getProductById
app.get('/products/category/:categoryId', verifyToken, getProductsByCategoryId); // Changed to getProductsByCategoryId
app.post('/products', verifyToken, checkIsAdmin, validateProductInput, create); // Changed to create
app.get('/products', verifyToken, getAllProducts); // Added getAllProducts

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});